class Tag:
    def set_tag_id(self, tag_id):
        self.tag_id = tag_id

    def set_tag_name(self, tag_name):
        self.tag_name = tag_name

    def set_tag_option_id(self, tag_option_id):
        self.tag_option_id = tag_option_id

    def set_tag_option_name(self, tag_option_name):
        self.tag_option_name = tag_option_name

        