class Activity:

    def set_activity_id(self, activity_id):
        self.activity_id = activity_id

    def get_activity_id(self):
        return self.activity_id

    def set_description(self, description):
        self.descritpion = description

    def get_description(self):
        return self.descritpion

    def set_activity_time(self, activity_time):
        self.activity_time = activity_time

    def get_activity_time(self):
        return self.activity_time

    