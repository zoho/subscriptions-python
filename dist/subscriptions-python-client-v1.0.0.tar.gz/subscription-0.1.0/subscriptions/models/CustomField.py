class CustomField:

    def set_value(self, value):
        self.value = value

    def set_label(self, label):
        self.label = label