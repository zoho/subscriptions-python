class PaymentGateway:
    def set_gateway_name(self, gateway_name):
        self.gateway_name = gateway_name

        